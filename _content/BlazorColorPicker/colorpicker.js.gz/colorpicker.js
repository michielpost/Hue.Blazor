﻿function SetFocusTo(element) {
    if (element instanceof HTMLElement) {
        element.focus();
    }

}