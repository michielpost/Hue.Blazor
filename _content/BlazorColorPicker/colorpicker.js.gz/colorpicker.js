﻿function SetFocusTo2 (element) {
    if (element instanceof HTMLElement) {
        element.focus();
    }
}